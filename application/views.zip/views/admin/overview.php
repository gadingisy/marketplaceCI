
<!DOCTYPE html>
<html lang="en">
<head>
    <?php $this->load->view("admin/_partials/head.php") ?>
</head>
<body id="page-top">
<div id="wrapper">
<?php $this->load->view("admin/_partials/sidebar.php") ?>
<?php $this->load->view("admin/_partials/navbar.php") ?>


    <div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Analytics Data</h1>
            <a href="tambah-produk.html" class="btn btn-success btn-icon-split">
                
                
              </a>  
          </div>
            
          <!-- Content Row -->
          <div class="col-xl-3 col-md-12 mb-4"></div>
          <h1 class="font-weight-bold text-center font-italic">Coming Soon!</h1>
          <div class="row justify-content-between border-bottom-danger">
<!-- Sticky Footer -->
                </div>
          </div>
          


          <?php $this->load->view("admin/_partials/footer.php") ?> 
        <!-- /.container-fluid -->

      </div>

      

<?php $this->load->view("admin/_partials/scrolltop.php") ?>
<?php $this->load->view("admin/_partials/modal.php") ?>

<?php $this->load->view("admin/_partials/js.php") ?>
    
</body>
</html>