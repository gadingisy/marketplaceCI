<footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto ">
            <span>Copyright &copy; G-dunk</span>
          </div>
        </div>
      </footer>
      <script>
	initSample();
</script>