<?php

class Contoh_model extends CI_Model{

    public function get_data(){
        
    }
}

?>